const exp=require("express")
const m=require("mongoose")
const app=exp()
const url='mongodb://localhost/stud'
m.connect(url)
const con=m.connection
con.on('open',()=>{
    console.log("welcome")
})
app.use(exp.json())
const stuRouter=require('./controller/control')
app.use('/stud',stuRouter)

app.listen(9000,()=>{
    console.log("server conected")
})