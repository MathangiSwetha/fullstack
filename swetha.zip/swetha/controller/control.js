const express= require('express')
const router=new express.Router()
const s1=require('../model/model')
router.get('/',async(req,res)=>{
    try{
        const stud=await s1.find()
        res.json(stud)
    }
    catch(err){
        res.send('error'+err)
    }
})
router.post('/',async(req,res)=>{
    const student1=new student1({
        rollno:req.body.rollno,
        name:req.body.name
    })
    try{
        const s3=await student1.save()
        res.json(s3)

    }
    catch(err){
        res.send('error'+err)
    }
})
module.exports=router